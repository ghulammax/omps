<section class="py-3">
    <div class="container">
        <h3 class="text-center fw-bolder">KPPN TAKENGON</h3>
        <hr>
        <div>
            <?php include "about.html" ?>
        </div>
    </div>
</section>